package make.qeen;

public class Ending {

	GamePrint gp = new GamePrint();

	public void neet() {
		try {
			System.out.println(gp.name + " 공주님은 아무것도 하지 않았습니다 공주님은 백수가 되었습니다.");
			Thread.sleep(150);
			System.out.println("뭐 공주니까 상관없겠죠, 놀고먹는게 최고니까요");
			Thread.sleep(150);

			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⡿⣟⣻⣭⣭⣭⣽⣛⡿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⡟⣵⣾⣿⣿⣿⣿⣿⣿⣿⣿⣮⡻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⡟⣼⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡝⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣧⣿⣿⣿⣿⣿⣿⠿⢿⠏⡉⠛⠛⢿⡿⢹⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⡇⣿⠀⠈⠉⢛⠋⠀⠈⠁⠀⡀⠀⠀⠀⢀⣹⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣷⢿⡄⠀⠐⠁⠀⡀⠀⠐⠛⠀⠀⠀⢰⣖⣞⣯⣭⣭⣭⣻⡯⣽⡻⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣼⡇⠀⠀⠀⠉⠁⠀⠄⠀⠀⠀⠀⡸⢶⣿⣏⡏⣷⣿⣻⣯⣿⡟⣷⡽⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣇⣇⠀⠀⠀⠀⠀⠀⠀⠐⠀⢀⣰⣾⢸⣟⣿⣧⣷⣿⣽⣻⣿⡷⣷⣮⣷⣶⢲⣖⣾⡏⠈⢛⢿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⡇⣿⣶⡴⣾⣗⣦⡾⣩⣷⣝⣿⡿⣫⣿⣿⣿⣹⣿⣿⣿⣾⣷⣿⣿⣿⢿⣿⣺⣷⣿⣿⠀⠀⣥⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣶⣯⣭⣽⣷⣶⣮⡻⣿⣧⠄⠈⠙⡿⣟⣼⣿⣿⣮⣛⢿⣿⣿⡿⣿⣿⣿⣟⢻⠿⣟⡀⠠⣸⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣮⡳⠠⢔⣦⣾⣿⣿⣿⣿⣿⣿⣿⣾⣭⣽⣿⣯⣭⣵⣶⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void endFarm() {
		try {
			Thread.sleep(150);
			System.out.println(gp.name + " 공주님은 농장알바를 열심히 했죠");
			Thread.sleep(150);
			System.out.println("그래서 농부가 되시기로 결정하셨어요!");
			System.out.println("식량 난이니까요 식량을 키우는건 아주 중요한 일이죠");
			Thread.sleep(150);
			System.out.println("성실하게 살아가는 공주님이 자랑스럽네요!");
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⢿⣛⣻⣟⣛⡿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⢟⣽⣾⣿⣿⣿⣿⣿⣿⣮⡝⣿⡿⠿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡏⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣶⠟⡡⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠿⢋⣵⡾⣷⡻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣧⢿⣿⣿⣿⡿⠟⠛⣉⠀⠈⠉⠃⠀⠀⣗⣻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⢫⣵⠿⢛⠉⠡⠤⠀⠀⠡⣄⠀⠀⠀⠰⠐⡿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣾⣿⣮⡂⠀⠘⠆⢀⠀⠀⠀⠀⠀⠀⠀⢻⣮⡻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣄⡀⠀⠀⠐⠒⠀⢀⡀⠀⠀⠈⠉⠱⣹⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠰⠆⠀⠀⢈⣿⣷⣤⣶⡀⠀⠀⣿⣝⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠀⠀⠀⢠⣶⣝⣿⣿⣿⣀⡀⢠⠿⢿⡞⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠀⠀⠀⣼⡿⣫⣿⡿⠃⠀⠀⠖⣪⣼⣧⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣣⠒⠂⠀⢟⣁⣭⡶⢞⣤⢤⣴⣿⣿⣿⡏⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⢿⣈⠈⠕⢹⣫⣭⣶⣾⣿⣳⡇⣿⣿⣿⣿⣧⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⡿⠿⣟⡻⣿⢿⣛⣯⡷⠾⠻⠭⠲⠬⠷⣧⢻⣿⣿⣿⡘⣓⢹⣿⣿⣿⣏⢻⡿⢿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⠿⣛⢸⣿⣿⣿⡾⢛⣋⣥⣶⣾⣿⣿⣿⣿⣿⣿⣄⢻⣿⣿⣷⢹⣧⡙⣿⣿⣿⡎⣿⣷⣮⣝⢿⣿⣿");
			System.out.println("⣿⡿⣥⣿⣧⠺⣿⣿⣿⣧⢻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⢀⣿⣿⣿⡆⣿⠗⣹⣿⣿⣿⢸⣿⣿⣿⣷⡝⣿");
			System.out.println("⣿⢸⣿⣿⣿⣷⠸⣿⣿⣿⡆⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣶⣶⣶⣶⣶⣿⣷⣶⣴⣶⣶⣾⣿⣿⣿⣿⣷⣿");
			Thread.sleep(150);
			System.out.println("⣿⣸⣿⣿⣿⣿⣀⡛⠋⡉⠁⢸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⢷⣿");
			Thread.sleep(150);
			System.out.println("⣿⣷⣝⡻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠿⠿⣛⣵⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣶⣾⣿⣭⣭⣽⣯⣽⣿⣿⣭⣿⣽⣭⣭⣭⣭⣭⣭⣭⣭⣭⣭⣭⣭⣿⣿⣶⣶⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void endCafe() {

		try {
			System.out.println(gp.name + " 공주님은 식당 알바가 즐거웠나봐요");
			Thread.sleep(150);
			System.out.println("공주님께서는 식당에 취직하기로 하셨어요!");
			System.out.println("언젠가 직접 식당을 여는게 꿈이시래요");
			System.out.println("공주님의 꿈이 이루워졌으면 좋겠네요!");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠿⠛⣉⣉⣭⣤⣤⣤⣉⡙⠻⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠋⣠⣴⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣄⠙⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠏⣠⣾⣿⣿⣿⣿⣿⣿⠿⠛⠛⠉⠉⠉⣁⡀⠈⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣄⡉⠛⣿⡿⠟⠋⣁⣤⡴⣶⣾⠟⡿⠟⠙⢷⡀⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠀⣋⣤⣶⠟⠈⡥⠤⠀⠀⠀⠶⠦⠀⠀⠇⢸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠀⣿⣿⡇⠀⠀⣠⢴⡀⠀⠀⡤⢴⠀⠀⠀⢸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠄⠟⠿⠇⠀⠀⠉⠈⠁⠀⠀⠁⠈⠁⠀⠀⢸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠄⣄⠀⡀⠀⠀⠀⠀⠀⠐⠂⠀⠀⠀⠀⠀⣸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡆⢻⣿⣿⣆⠀⠀⠀⠳⠴⠃⠀⠀⠀⠀⣠⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⡈⠿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠠⢾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡟⢁⣴⣿⡇⠀⠛⠒⠒⠒⠒⠂⠈⢷⡈⢻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡟⢀⣾⣿⡏⠀⠀⠀⠀⠀⢠⣾⡆⠀⠸⠷⡀⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠁⣾⣿⣿⠇⠀⠀⠀⠀⠀⢀⠀⠀⡀⠀⠀⢀⠸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⢸⣿⣿⣯⠀⠀⠀⠀⣾⣿⣿⣿⣿⣷⡿⠀⠉⠀⠉⠻⠿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⢸⣿⣿⣿⣿⣦⣴⣶⣿⣿⣿⣿⣿⣿⣿⣶⣾⣿⣷⣾⡆⢹⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⡀⠻⠿⠄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⣴⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⠂⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢶⣶⣶⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡏⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡟⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡄⢠⣤⣤⣤⣤⣤⣤⣤⣤⣤⣤⣤⣤⣤⡄⢀⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠈⠛⠛⠛⠛⠛⠛⡿⠛⠛⠛⠟⠋⣉⠃⣸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠀⠀⠀⢠⠁⠀⠀⣸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠀⡀⠀⢸⡀⢀⡀⠻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣄⣙⠛⠛⠋⣉⣉⣠⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");

		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void endChild() {
		try {
			System.out.println(gp.name + " 공주님은 아이들을 좋아하셨죠");
			Thread.sleep(150);
			System.out.println("그래서 계속 아이들을 돌보고 싶으시대요");
			System.out.println("공주님과 잘 어울리는 직업인것 같아요!");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⣻⣿⣶⣿⣿⣾⣝⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⣿⣿⣿⣿⡿⣿⠟⠛⢯⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡷⣿⡿⠋⠥⠄⠁⠀⠄⠘⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⠛⠃⠀⠐⠂⠀⠎⠃⠀⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⢠⣦⠀⠀⢀⢀⠀⠀⢸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡼⣿⣷⡦⢤⣤⣴⡴⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣼⣿⣷⣶⣾⣿⣿⣟⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⢷⣿⡿⠟⠛⠿⣿⣿⣿⡾⣿⣿⣿⣿⣿⡿⣟⣿⣟⣻⢿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣫⣷⣿⣿⣷⣯⣛⡛⣿⣿⣿⣏⣿⣿⣷⣀⣁⣸⣿⣿⣿⣿⣽⣿⣿⡯⣷⣿⣿⣿⣿⣿⣷⣽⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣷⣿⣿⣿⣿⣿⣿⠟⢽⣿⣿⡿⣾⣿⡻⣿⣿⣿⣿⣿⣿⣞⣿⣷⢻⣿⡏⠋⠽⠛⢿⣿⣿⣿⡇⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣟⣿⡟⠻⠛⠀⠀⠄⠀⣿⡿⠻⣿⢯⣧⡏⠉⠉⠉⠉⣿⣿⣟⣿⠯⢿⡇⠀⠆⠀⢠⠀⠙⣿⣇⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⠝⠃⠀⠈⠁⣀⡀⠀⣾⠠⠋⢇⣿⣿⣷⣄⣀⣠⣼⣿⣧⣿⠰⠱⠀⣇⠀⢨⣤⡀⠀⢀⣀⡹⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣧⣤⢤⠤⠤⠽⠛⢹⣯⣷⣶⣼⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣦⣬⣾⣿⡗⠮⢭⠤⠴⣟⣭⣷⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⡿⢿⣿⣵⣿⣦⣴⣿⣾⣿⢛⣛⣿⣿⣿⢹⣿⣿⣿⣿⣿⣿⣿⣿⣿⣮⣛⣿⣿⣿⣿⣷⣾⡿⣿⣾⡝⠙⣹");
			Thread.sleep(150);
			System.out.println("⣿⡄⠁⣟⣯⣻⣿⣿⣿⣿⣿⣯⣿⣿⣿⣿⡌⣿⣿⡟⣭⣽⣿⣿⡾⣿⣿⣿⣯⣿⣿⣿⣿⣿⣷⢷⣾⣥⣤⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⡿⢿⣿⣿⣿⣿⣿⡿⢼⣿⣿⣿⣿⣿⣿⢿⣿⣷⣻⣿⣿⣻⣿⣿⣹⣿⣿⣿⣿⣿⣿⢿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⢻⣏⠀⢀⣭⣿⣮⣭⣀⣀⣼⣓⣿⣿⣿⣿⣿⣾⣿⣿⣷⣻⣿⢿⡟⣿⣄⣀⣾⣿⣿⣅⣠⣼⣏⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣷⣯⣽⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣽⣻⣇⣿⣿⣿⣿⣿⣷⣿⣿⣷⣿⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void freetor() {
		try {
			System.out.println(gp.name + " 공주님은 아직 적당한 직업을 못 고르셨대요");
			Thread.sleep(150);
			System.out.println("아르바이트라도 꾸준히 하면 좋았을텐데.....");
			System.out.println("지금이라도 여러 알바를 하면서 생활해보시겠대요");
			System.out.println("뭐... 노는것 보다는 낫죠");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣟⣽⣶⣾⣿⣶⣯⡻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⣼⣿⣿⣿⣿⣿⣿⣿⢹⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣜⠋⠑⠀⠈⠛⠛⢻⣿⢸⣿⣟⠛⠛⣻⢿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠀⠀⠁⠀⠈⠀⠀⣀⢿⣿⠟⠿⠅⣖⡌⠪⢿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠿⣿⣿⣿⣿⣿⣞⡄⡀⠒⠀⠀⣼⡿⣿⣿⣷⣾⣵⣊⣽⣥⣼⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⢟⢕⢉⡮⣿⣿⣿⣿⣿⡟⣵⣷⣶⣶⣾⣿⣞⢿⣿⣿⣿⡿⣟⣿⣿⣿⣻⢿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣏⢣⢒⢃⢕⣼⣿⣿⡿⢯⠙⢉⣙⣀⠀⢛⡟⠛⠚⣿⣿⣟⣾⣿⣿⣿⣿⣿⣷⣻⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣲⣢⣲⣿⣿⣿⢖⠒⠒⠒⠒⡒⠆⠀⠂⠁⠀⣄⣿⣿⢻⠿⠛⣉⠉⣙⠛⠿⠿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⢿⣿⠿⢷⣯⣿⣭⣏⣿⣿⣿⣶⣾⣷⣾⣿⣿⠍⠁⠀⠆⠀⠰⠀⠈⠀⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣟⣵⣿⣿⣿⣿⣷⣟⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣕⠀⠀⠤⠀⣀⣾⣽⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣼⡿⠿⠛⠛⠛⠿⢿⣾⣿⣯⣽⣿⣯⣽⣭⣵⣿⣿⣿⣿⣳⣿⣶⣶⣶⣿⣧⢿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⡷⡡⠀⠀⡀⠀⣄⠀⠰⠧⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⠿⠹⣿⣿⣤⡄⠟⣾⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⢫⠭⢭⣭⣭⡝⣇⠄⡀⠀⢀⠂⠀⠀⣀⢜⣿⡿⠿⠿⠿⠿⢿⡻⣿⣿⣿⡟⡀⠐⠙⢟⣟⠀⠀⣛⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⡸⠶⢿⡿⠿⢇⣿⣿⡮⣢⡀⠀⣠⣶⡿⣸⣿⣷⢴⠂⠀⠀⠦⣵⣿⣿⣫⣭⣬⣶⣶⣷⣶⣦⣦⣭⣭⢻⣿");
			Thread.sleep(150);
			System.out.println("⣿⡿⣿⣿⣿⣿⣿⣛⡿⡇⢰⣿⣿⡇⠀⢸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣼⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⢻");
			Thread.sleep(150);
			System.out.println("⣷⣷⣤⣤⣤⣤⣤⣤⣬⣥⣬⣭⣭⣭⣥⣬⣤⣴⣿⢸⣿⣿⣿⣿⣿⣇⠿⠿⠿⠿⠿⠿⠿⠿⠿⠿⠿⠿⠿⣿");
			Thread.sleep(150);
			System.out.println("⣯⣭⣭⣭⣭⣭⣭⣭⣭⣭⣭⣭⣭⣭⣭⣭⣭⣭⣭⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void genal() {
		System.out.println(gp.name + " 공주님은 이 나라를 집접 지키기로 하셨어요");
		try {
			Thread.sleep(150);

			System.out.println("지금까지 배운 무술로 군인이 되시겠대요!");
			System.out.println("곧 장군승진까지 어렵지 않을거예요!");
			System.out.println("뭐... 공주잖아요? 원래 승진은 출신이죠");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠿⠟⢛⣩⣥⣤⣬⣍⡛⠻⠿⠿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠟⣡⡆⠺⣿⣿⡟⠫⠀⠟⢻⣿⣿⠃⣰⣌⠻⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⠟⣡⣾⣿⣿⡄⠙⣿⢇⣲⣀⣶⡸⣿⠃⣰⣿⣿⣷⣦⡙⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⠸⣿⣿⣿⣿⠟⠂⣈⣡⣤⣤⣤⣤⣄⣀⡉⠛⠿⣿⣿⠇⣸⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⡌⢿⣟⣡⣶⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣦⡼⢋⣼⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠆⣿⣿⣿⠿⠿⠿⠿⠿⠿⠿⠿⠿⢿⣿⣿⠀⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠀⣿⣿⡇⠀⠈⡙⠀⠀⠀⢚⠉⠀⢸⣿⣿⡇⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡏⣼⠛⠛⠁⠀⠐⠟⠀⡄⠀⠺⠃⠀⠈⠿⠛⢷⢸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣇⠹⣄⣀⠀⠀⠀⠀⢜⡀⠀⠀⠀⠀⠀⢤⣶⠞⣸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⡘⢿⡄⠀⠀⠀⣀⠀⢀⠀⠀⠀⢀⣿⠏⣼⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡦⠙⢦⡀⠀⠈⠉⠁⢀⣀⣤⣾⣿⡄⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠟⣡⣶⣾⣿⣿⣿⡶⣶⠾⢟⣿⣿⣿⣿⣧⣌⢻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠃⣾⣿⣿⣿⣿⣿⣿⣷⣄⣴⣿⣿⣿⣿⣿⣿⣿⣆⢹⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⡏⣸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠀⠀⠀⣿⣿⣿⣿⡆⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⢁⣿⣿⣿⢻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠻⣿⣿⣿⡈⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⢸⣿⣿⡏⢸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡄⢻⣿⣿⣷⠸⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣇⢸⡿⠿⢇⣸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣇⠘⠛⠉⠘⡆⢿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⡆⣗⠀⠀⠸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡀⠀⠀⠀⢳⠸⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⢹⠀⠀⢀⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣇⠀⣀⠀⠸⡄⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⢸⠀⠀⡘⠛⠻⠿⠿⠿⠿⣿⣿⣿⡏⠯⠡⠈⠋⠀⠀⠀⢀⡇⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠸⡇⠀⣿⣿⣶⣶⣶⣦⣤⣤⣤⣤⣼⣍⠁⠀⠀⠀⣀⡤⠊⣴⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡀⡇⠀⢻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣶⡖⣋⣥⣶⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⡇⠀⢸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠀⡇⢀⢸⣿⣿⣿⣿⣿⡇⢿⣿⣿⣿⣿⣿⣿⢃⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡆⢧⠀⢾⣿⣿⣿⣿⣿⡇⢸⣿⣿⣿⣿⣿⣿⢸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣌⠳⣼⣿⣿⣿⣿⣿⡇⢸⣿⣿⣿⣿⣿⣿⢸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⢹⣿⣿⣿⣿⣿⡇⢸⣿⣿⣿⣿⣿⡟⢸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⢸⣿⣿⣿⣿⣿⡇⢸⣿⣿⣿⣿⣿⡇⣸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠸⣿⣿⣿⣿⣿⡇⢸⣿⣿⣿⣿⣿⡇⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡀⣿⣿⣿⣿⣿⡇⢸⣿⣿⣿⣿⣿⠃⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⣿⣿⣿⣿⣿⡇⢸⣿⣿⣿⣿⣿⢰⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⣿⣿⣿⣿⣿⡇⢸⣿⣿⣿⣿⣿⢸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⢻⣿⣿⣿⣿⡇⠘⣿⣿⣿⣿⡏⢸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⣼⡿⠿⠿⠟⠃⠀⠿⠿⠟⠛⠃⢸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠏⣡⣿⣷⣶⣶⣶⣾⣀⣶⣶⣶⣶⣷⣌⢻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡘⠿⠿⠿⠿⠿⠿⠿⠿⠿⠿⠿⠿⠿⠿⢸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void artist() {
		System.out.println(gp.name + "공주님께선 그림그리기를 즐거워하셨죠");
		try {
			Thread.sleep(150);

			System.out.println("계속 그림을 그리시겠대요!");
			System.out.println("공주님의 그림은 인기 만점이예요");
			System.out.println("왕궁에서 전시회를 한다니 기대되네요!");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠛⠛⠛⠛⠛⠛⠛⢸⣿⠿⠞⠛⠛⠛⠛⠛⠿⠿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⡿⢟⣛⣿⣿⣛⡿⢿⣿⣿⣿⣿⣿⠀⠀⠀⠀⠀⠀⠀⠈⠉⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⡿⣻⣾⣿⣿⣿⣿⣿⠿⣷⣝⣿⣿⣿⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣽⣿⣿⣿⠻⠟⠈⠟⣀⣈⢻⢸⣿⣿⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⡇⣿⣿⡿⠃⠈⢉⠀⠀⠀⡀⠀⢸⣿⣿⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⡇⠟⠛⠀⠀⠀⠛⠀⠀⠈⠁⠀⢸⣿⣿⣿⠀⠀⠀⢀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣷⢀⣀⠀⠀⠀⠀⠀⠀⡁⠀⠀⢸⣿⠿⠿⣤⣤⣔⣻⡷⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠐⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⢸⣿⣧⡀⠀⠀⠈⠉⠁⢀⣴⣯⡞⠀⠀⠈⠉⠈⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣷⣭⢻⣿⣷⡶⠒⠶⠝⠿⠛⠉⠀⠀⣠⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⢸⣿⣿⠁⠀⠀⠀⠀⠀⠀⣠⠾⠿⡀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⡿⣿⣿⣤⣴⣤⣤⠤⠂⠈⡾⠭⣽⣏⠽⠤⡞⣻⣆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣇⣿⣿⣿⣿⣿⣿⡦⣠⣤⣭⣚⣓⠖⠛⠚⠛⠋⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣷⣿⣿⣿⣿⣿⣿⣿⣝⢿⣿⣿⢿⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⡟⢿⣿⣿⣿⣿⣿⣿⣿⣿⣶⣝⢻⣿⣿⣿⡿⡿⠿⠿⠿⢿⣿⠿⣿⢶⣶⣶⣶⣶⣾⡇⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣷⣬⣙⣛⠛⠿⠿⢿⣿⡿⢹⢹⣿⣧⣿⢳⣿⣿⣿⣿⣿⣿⢸⣿⣿⡼⣿⣹⣷⣾⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⢰⢸⣿⣿⣿⠉⢸⣿⡇⢸⢸⡟⣾⣏⣿⣿⣿⣿⣿⡇⣿⣿⣿⣿⣧⢿⣏⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⢸⢸⣿⣿⣿⠀⡀⣿⡇⠸⣿⣗⣿⣼⣿⣿⣿⣿⣿⣿⣶⣾⣿⣿⣿⡾⣿⢸⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣺⣸⣷⣾⣿⠿⣰⡆⢠⣄⡰⣟⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣶⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void musician() {
		System.out.println(gp.name + "공주님은 유독 음악적 소양이 뛰어나셨죠 ");
		try {
			Thread.sleep(150);

			System.out.println("그러니 음악가가 되는건 당연한거예요");
			System.out.println("벌써 내일 왕궁에서 공주님의 음악회가 열려요");
			System.out.println("다들 참석 하실거죠?");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⡿⣻⣿⠿⢿⣿⣿⣿⣿⡿⣟⣻⣭⣭⣭⣽⣟⡿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⢷⢳⣶⡏⡇⣿⣿⡿⣽⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⡽⣿⣿⣿⣿⣿⡿⡎⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⡲⠾⣸⡱⠶⢽⣿⡟⣾⣿⠿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡞⣿⣿⣿⢻⣥⡇⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⢻⣿⠃⠀⠈⠙⠛⠈⠛⣻⠿⢿⣿⣿⣿⢹⣿⣿⣷⣷⣾⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⢸⡿⠀⠠⠖⠒⠀⠀⠈⠉⠉⠀⠀⠸⣿⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⢯⢹⣿⣿⣿⣿⣿⣿⢸⡇⠀⠀⣀⢀⡄⠀⠀⢦⡴⠂⠀⠀⠀⠀⢹⣿⣿⣿⣿⣿⣿⢯⢭⣻⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⠿⢸⣼⣿⣿⣿⣿⣿⣿⣼⣷⠀⠀⠈⠋⠀⢀⠀⠀⠁⠀⠀⠀⣤⡄⣾⣿⣿⣿⣿⣿⣛⣼⢦⣇⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣧⣛⣛⣼⣿⣿⣿⣿⣿⣿⣇⣿⣆⡀⠀⠀⠀⠀⣀⡄⠀⠀⠀⣾⣿⣇⣿⣿⣿⣿⣿⣷⣭⣭⣾⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣹⣿⣿⣶⣤⠤⠤⠤⠤⠶⠚⣫⣿⣿⣹⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⢿⠿⣿⣿⣿⣿⣿⣷⡻⣿⣿⣿⣷⣤⣀⣀⢤⣶⣿⣿⣷⢿⣿⣿⣿⣿⣿⣻⣛⣻⠿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⡿⡟⢽⣼⣿⣿⣿⣿⡿⣵⣿⡿⣿⣿⣿⣿⡿⣿⣿⣿⣿⣿⣼⣿⣿⣿⠿⢧⢷⣷⡾⡽⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣗⣾⣗⣶⣾⣿⣿⣿⠋⠈⠻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠛⠋⠃⣿⣿⣿⣝⣛⣼⣱⠿⣹⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡟⠁⠀⠀⠀⣩⣿⣽⣿⣿⣿⣿⣿⣿⣿⠀⠀⠀⠸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⢟⡿⠛⠛⠛⠛⣟⣀⠘⣡⣌⡟⠛⠛⠛⠛⠛⠛⠛⠛⠛⣻⢂⡄⠀⢐⡾⠛⠛⠛⠛⠛⢿⡻⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⡿⣳⡟⠀⢀⡦⣠⢄⡤⠈⠛⡯⢨⠅⠀⢰⡄⣦⢠⡄⠀⢠⡄⣮⠉⠓⣶⠻⡄⢦⠀⠀⢦⡠⣌⢻⣝⣿⣿");
			Thread.sleep(150);
			System.out.println("⣟⣿⣿⣶⣶⣾⣶⣿⣾⣷⣶⣾⣷⣿⣶⣶⣾⣶⣷⣾⣷⣶⣾⣷⣾⣶⣶⣾⣶⣿⣾⣷⣶⣾⣷⣾⣶⣿⣯⢻");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⢸");
			Thread.sleep(150);
			System.out.println("⣷⣶⣶⣶⣶⣶⣶⣶⣶⣶⣶⣶⣶⣶⣶⣶⣶⣶⣶⣶⣶⣶⣶⣶⣶⣶⣶⣶⣶⣶⣶⣶⣶⣶⣶⣶⣶⣶⣶⣿");
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void servent() {
		System.out.println(gp.name + "공주님은 뭐든 다 잘하셨지만... ");
		try {
			Thread.sleep(150);

			System.out.println("특별하게 꼭 되고싶은건 없으셨대요");
			System.out.println("나라를 위해 봉사하는 것, 그게 왕족의 의무시라며..");
			System.out.println("나라와 백성들을 위해 끝까지 일하시겠대요");
			System.out.println("말단 공무원이라니 쉽지 않겠지만 공주님을 응원해요!");
			Thread.sleep(150);

			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠿⢿⣿⣿⠿⠿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⠟⠋⠉⠒⠲⣶⣯⣭⣛⢿⣿⣿⣿⣿⢟⣭⣶⣿⣿⣿⣿⣿⣿⣶⣝⢿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⠋⠀⠀⠀⠀⠀⢀⣿⡏⠀⠀⠀⠙⢿⣿⣇⣾⡿⠋⠻⣿⣿⢿⣿⣿⣿⣿⣧⢻⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⠃⠀⠀⠀⠀⠀⠘⠻⣿⣿⣦⡀⠀⠀⠀⢻⣽⡏⠀⣀⢄⠀⠉⠀⡉⣟⠿⠿⣿⡇⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⡇⡀⠀⠀⢀⣴⡀⢀⣰⣿⣿⣿⡁⠀⠀⠀⠈⡇⠁⠀⠐⡤⡄⠀⠀⡦⡄⠀⠀⢹⣿⣹⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⡇⣷⣴⣾⣿⣿⣿⡿⠋⠉⠻⣿⣿⣶⣶⣶⡆⣇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠈⢸⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣷⢻⣿⣿⣿⡟⠁⠀⠀⠀⠀⣿⣿⣿⣿⣿⣹⣿⠀⠀⠀⠀⠈⠁⠀⠀⠀⠀⠀⣶⡖⣾⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣧⡻⣿⣿⣧⣄⡀⠀⠀⢀⣿⣿⣿⡿⣱⣿⣿⣧⡀⠀⠀⠈⠂⠚⠀⠀⢀⣼⣿⣷⡹⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣮⣛⠿⣿⣿⣿⣿⣿⡿⢟⣫⣾⣿⣿⣿⣿⡿⣪⣷⠦⠤⠴⠶⣾⣿⡿⣋⣶⣶⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⠒⠒⠻⠶⠖⠸⣿⣿⣿⣿⣿⣿⢫⣾⣿⣿⡄⠀⠀⢀⣿⣿⣷⡜⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣧⡀⠀⠀⡐⠀⠀⠻⣿⣿⣿⣿⣣⣿⣿⣿⣿⣇⠀⠀⢸⣿⣿⣿⣿⡜⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣶⣦⣄⠀⣾⣿⣮⣝⠿⢱⣿⣿⣿⣿⣿⣿⠀⠀⣸⣿⣿⣿⣿⣷⢹⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣝⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡆⠀⣿⣿⣿⣿⣿⣿⡞⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣝⢿⣿⣿⣿⣿⢿⣿⣿⣿⣧⢸⣿⣿⣿⣿⣿⣿⡇⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣮⣭⣵⣶⢸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣇⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⢸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⢸⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⣼⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⢸⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⢸⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⢸⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠿⠿⢺⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⢸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣇⠃⢀⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣸⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⣴⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⣿⣿⣿⣿⣿⣿⣿⣿⣿⣇⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣇⡛⠛⠛⠛⡿⠿⠿⠿⣿⣹⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⡇⠀⠀⠀⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠀⠀⠀⡇⠀⠀⠀⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠀⠀⠀⠃⠀⠀⢱⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠄⠀⣀⣇⠀⠀⠸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣧⣛⣛⣯⣭⣝⣛⣛⣸⣿⣿⣿⣿⣿⣿⣿⣿⣿");
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void Qeen() {
		System.out.println(gp.name + "공주님! 준비 끝나셨어요?");
		try {
			Thread.sleep(150);

			System.out.println("어휴 뭐하시는거예요!");
			Thread.sleep(150);
			System.out.println("오늘이 여왕 취임식인데 빨리 준비하셨어야죠!");
			Thread.sleep(150);
			System.out.println("뭐든 열심히 잘하시는 공주님.. 전 여왕이 되실줄 알고 있었어요");
			Thread.sleep(150);
			System.out.println("공주님을 올바르게 이끌어준 당신 덕분이예요...!");
			Thread.sleep(150);
			System.out.println("분명 공주님은 이 나라를 훌륭히 다스리실거예요..!");
			Thread.sleep(150);
			System.out.println("여왕 폐하 만세!");
			Thread.sleep(150);

			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡏⡝⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡟⠉⠈⠉⢹⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⣫⡷⢶⣄⢀⣔⡿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⢱⠖⢶⣿⣷⣾⣿⣿⠉⣻⠼⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡏⡞⢻⣷⣾⣿⣿⣿⣿⣿⣿⣿⠛⣶⣻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠃⠈⢻⣿⣿⣿⣿⣿⣿⣿⠋⠉⣿⣿⣻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⢟⣿⣿⣿⡇⢈⣿⣿⣿⣿⡀⢘⣿⣾⣿⣿⣧⣽⡻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⡇⣿⣿⣿⡿⠿⠟⢻⡇⢹⡟⠻⠿⣿⣿⣿⣿⣿⣿⡿⣽⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⢫⣾⣿⠏⠀⠀⠀⠀⠙⠚⠀⠀⠀⠀⠙⢿⣿⣿⣿⣷⡞⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⡹⣿⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣿⣿⣿⢣⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⡷⣿⣇⠀⠠⠤⠤⢄⠀⠀⠤⠴⠤⠀⠀⢸⣿⣿⣿⣿⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣷⣽⣓⠀⢠⢴⣶⢼⠀⠀⠤⣶⡤⠀⠀⠈⡿⠿⣿⣟⣼⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⢏⠀⠀⠀⠁⡟⠀⠀⠀⠉⠀⠀⠀⠀⠀⠀⠈⣧⠀⠈⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⠟⠃⠀⠀⠀⣧⠀⠀⠀⢀⠀⢀⡀⠀⠀⠀⢀⡾⠛⠛⠁⠀⠀⠀⠈⢻⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⣿⠄⠀⠀⠀⠀⢈⢧⣀⠀⠀⠉⠉⠀⠀⢀⡴⠟⡆⡀⠀⠀⠀⠀⠀⠀⢸⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⡿⠀⠀⠀⠀⠀⠀⠀⣏⣓⣦⣤⣤⡤⠶⣋⣀⣴⠋⠀⠀⠀⠀⠀⠀⠀⠀⢻⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⡧⠀⠀⠀⠀⠀⠀⠀⠈⣽⠳⠶⠟⠲⠚⠋⠁⢹⠀⠀⠄⠀⠀⠀⠀⠀⢘⣿⣿⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣿⢆⠀⠀⠀⠀⠀⠀⠀⢀⡇⠀⠀⠀⣀⠀⠀⠀⢸⡇⠀⠀⠄⠀⠀⠀⠸⣿⠿⣜⢿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣏⣶⡇⠀⠀⠀⠈⠠⠀⢸⡇⠀⠀⠸⣼⠇⠀⠀⠘⡇⠀⠄⠀⠀⣠⣦⣤⣿⣶⣿⡞⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⢸⠿⣷⣤⣤⣀⣀⡠⠀⢼⣧⣀⣀⣀⠀⠀⠀⠀⠀⣿⣀⣀⣼⣿⠿⣶⣧⣽⣿⣬⣷⢿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⢽⡷⣿⣏⣹⣿⡍⢻⣦⣤⣠⣍⠉⠉⠉⠋⠉⢉⣭⣥⣿⡇⢰⣿⣶⣿⡟⣻⣿⣉⣿⣿⣿⣿⣿⣿");
			Thread.sleep(150);
			System.out.println("⣿⣿⣿⣿⣸⣦⣿⣿⣛⣿⣷⡘⣿⣿⣾⣿⣷⣶⣾⣿⣶⣿⣶⣿⣿⠁⣼⣧⣼⡟⣿⣿⣉⣿⡇⣿⣿⣿⣿⣿");
			System.out.println("⣿⣿⣿⣿⣷⣭⣭⣭⣭⣭⣥⣽⣮⣭⣭⣭⣭⣭⣭⣭⣭⣭⣭⣭⣥⣼⣭⣭⣭⣭⣭⣭⣭⣭⣾⣿⣿⣿⣿⣿");

			Thread.sleep(1000);
			System.out.println("~여왕엔딩~");
			Thread.sleep(1000);
			System.out.println("공주님을 여왕으로 만드셨네요!");
			Thread.sleep(100);
			System.out.println("축하드립니다!!");
			Thread.sleep(100);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}